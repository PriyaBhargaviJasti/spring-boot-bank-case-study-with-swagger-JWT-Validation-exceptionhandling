package com.fis.bankapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
//import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "account_info")
public class Account {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "accNo")
/*	@GeneratedValue(generator = "sequence-generator")
    @GenericGenerator(
      name = "sequence-generator",
      strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
      parameters = {
        @Parameter(name = "sequence_name", value = "user_sequence"),
        @Parameter(name = "initial_value", value = "9900"),
        @Parameter(name = "increment_size", value = "1")
        }
    )*/
	private long accNo;
	@NotBlank(message = "account type cannot be null or whitespace")
	private String accType;
	@NotBlank(message = "branch cannot be null or whitespace")
	private String branch;
	@NotBlank(message = "ifsc cannot be null or whitespace")
	private String ifsc;
	private double balance;
	
	
	
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	public Account(long accNo, String accType, String branch, String ifsc, double balance) {
		super();
		this.accNo = accNo;
		this.accType = accType;
		this.branch = branch;
		this.ifsc = ifsc;
		this.balance = balance;
	}
	
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accType=" + accType + ", branch=" + branch + ", ifsc=" + ifsc
				+ ", balance=" + balance + "]";
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}