package com.fis.bankapp.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapp.exception.AccountNotFound;
import com.fis.bankapp.exception.NotEnoughBalance;
import com.fis.bankapp.model.Account;
import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.service.AccountService;
import com.fis.bankapp.service.TransactionService;

/*
{
"custId":1,
"accType":"savings",
"branch":"india",
"ifsc":"opiu",
"balance":10000
}
*/
@RestController
@RequestMapping("/accounts")
public class AccountController {
	long accNoFrom;
	long accNoTo;
	String transType;
	@Autowired
	AccountService service;
	
	@Autowired
	TransactionService service2;

	@PostMapping("/addAccount") // http://localhost:1111/accounts/addAccount
	public String saveAccount(@RequestBody Account account) {
		return service.addAccount(account);
	}

	@PutMapping("/updateAccount") // http://localhost:1111/accounts/updateAccount
	public String updateAccount(@RequestBody Account account) {
		return service.updateAccount(account);
	}

	@DeleteMapping("/deleteAccount/{accNo}") // http://localhost:1111/accounts/deleteAccount/888
	public String deleteAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
		try {
			return service.deleteAccount(accNo);
	}
		catch (AccountNotFound anf) {
			return "Account Not Found with given Account Number";
			
		}
	}

	@GetMapping("/getAccount/{accNo}") // http://localhost:1111/accounts/getAccount/888
	public Account getAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
		
		return service.getAccount(accNo);
	
	}

	
	@GetMapping("/depositIntoBalance/{accNo}/{depositAmount}") // http://localhost:1111/accounts/depositIntoBalance/888/888
	public String depositIntoBalance(@PathVariable("accNo") long accNo,@PathVariable("depositAmount") double depositAmount) throws AccountNotFound {
		Transaction transaction = new Transaction();
		accNoTo = accNo;
		transType = "Deposit";

		try {
			
			return service.depositIntoBalance(accNo, depositAmount);

		} catch (AccountNotFound anf) {

			return anf.getMessage();
		} finally {
			transaction.setAccNoTo(accNo);
			transaction.setAmount(depositAmount);
			transaction.setTransType(transType);
			transaction.setDateOfTrans(LocalDateTime.now());
			service2.addTransaction(transaction);
		}
	}
	
	@GetMapping("/withdrawFromBalance/{accNo}/{withdrawAmount}") // http://localhost:1111/accounts/withdrawFromBalance/888/888
	public String withdrawFromBalance(@PathVariable("accNo") long accNo,@PathVariable("withdrawAmount") double withdrawAmount) throws NotEnoughBalance, AccountNotFound {
		Transaction transaction = new Transaction();
		accNoFrom = accNo;
		transType = "Withdraw";
		try {
			
			return service.withdrawFromBalance(accNo, withdrawAmount);
		} catch (AccountNotFound anf) {
			
			return anf.getMessage();
		} catch (NotEnoughBalance nef) {
			
			return nef.getMessage();
		} finally {
			transaction.setAccNoFrom(accNo);
			transaction.setAmount(withdrawAmount);
			transaction.setTransType(transType);
			transaction.setDateOfTrans(LocalDateTime.now());
			service2.addTransaction(transaction);
		}
		
		
	}
		
	
	@GetMapping("/FundTransfer/{AccNoFrom}/{AccNoTo}/{amount}") // http://localhost:1111/accounts/FundTransfer/1/2/1000
	public String FundTransfer(@PathVariable("AccNoFrom") long AccNoFrom,@PathVariable("AccNoTo") long AccNoTo,@PathVariable("amount") double amount) throws AccountNotFound, NotEnoughBalance{
		
		try {
			return service.FundTransfer(accNoFrom, accNoTo, amount);
		} catch (AccountNotFound anf) {
			return anf.getMessage();
		} catch (NotEnoughBalance nef) {
			return nef.getMessage();
		} 
		
	}


}
