package com.fis.bankapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.service.TransactionService;


@RestController
@RequestMapping("/transactions")
public class TransactionController {
	@Autowired
	TransactionService service;

	@PostMapping("/addTransaction") // http://localhost:1111/transactions/addTransaction
	public String saveTransaction(@RequestBody Transaction transaction) {
		return service.addTransaction(transaction);
	}

	@GetMapping("/getTransactions/{transId}") // http://localhost:1111/transactions/getTransactions/888
	public List<Transaction> getTransactions(@PathVariable("transId") long AccNoFrom) {
		return service.getTransactions(AccNoFrom);
	}

	@GetMapping("/getAllTransactions") // http://localhost:1111/transactions/getAllTransactions
	public List<Transaction> getTransactions() {
		return service.getAllTransactions();
	}
	
	


}

