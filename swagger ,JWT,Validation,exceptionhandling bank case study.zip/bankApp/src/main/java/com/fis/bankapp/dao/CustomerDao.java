package com.fis.bankapp.dao;

import com.fis.bankapp.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CustomerDao extends JpaRepository<Customer,Integer> {
	
}
