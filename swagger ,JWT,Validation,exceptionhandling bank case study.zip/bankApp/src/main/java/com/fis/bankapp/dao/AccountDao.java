package com.fis.bankapp.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;

import org.springframework.data.jpa.repository.Query;
 
import com.fis.bankapp.model.Account;
 
public interface AccountDao extends JpaRepository<Account, Long> {
 
	@Query("Update Account set balance=balance+ ?2 where accNo=?1")
	@Modifying
	 public  void depositIntoBalance(long accNo, double depositAmount);
 
	@Query("Update Account set balance=balance - ?2 where accNo=?1")
	@Modifying
	public  void withdrawFromBalance(long accNo, double withdrawAmount);
 
	

	
}



