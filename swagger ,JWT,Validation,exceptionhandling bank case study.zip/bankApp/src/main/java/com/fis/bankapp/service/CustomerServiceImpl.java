package com.fis.bankapp.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.dao.CustomerDao;
import com.fis.bankapp.exception.CustomerNotFound;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerDao dao;

	@Override
	public String addCustomer(Customer customer) {
		dao.save(customer);
		return "Customer added successfully";
	}

	@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {
		dao.save(customer);
		return "Customer updated successfully";
	}

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {
		Optional<Customer> optional = dao.findById(custId);
		if(optional.isPresent()) {
			dao.deleteById(custId);
			return "Customer deleted successfully";
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}
	}

	@Override
	public Customer getCustomerById(int custId) throws CustomerNotFound {
		Optional<Customer> optional = dao.findById(custId);
		return optional.get();
		//return dao.getCustomer(custId);
	}

	@Override
	public List<Customer> getAllCustomers() {
		return dao.findAll();
	}

	

}
