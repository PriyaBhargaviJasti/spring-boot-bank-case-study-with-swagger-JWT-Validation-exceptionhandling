package com.fis.bankapp;

import java.time.LocalDateTime;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.dao.CustomerDao;
import com.fis.bankapp.service.CustomerService;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.dao.AccountDao;
import com.fis.bankapp.service.AccountService;

import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.dao.TransactionDao;
import com.fis.bankapp.exception.CustomerNotFound;
import com.fis.bankapp.service.TransactionService;

@SpringBootTest
//@RunWith(MockitoJUnitRunner.class)
class BankAppApplicationTests {

	@Autowired
	CustomerService service;
	@Autowired
	AccountService service2;
	@Autowired
	TransactionService service3;

	@Test
	public void testAddCustomer() {
		Customer customer = new Customer(123,"priya",new Date(), 45678, "priya@gmail.com", "fcgvhb");
		//Mockito.doReturn("Customer added successfully").when(service).addCustomer(customer);
		String msg = service.addCustomer(customer);
		assertEquals("Customer added successfully",msg);
	}
	@Test
	public void testUpdateCustomer() throws CustomerNotFound {
		Customer customer = new Customer(123,"priya",new Date(), 45678, "priya@gmail.com", "fcgvhb");
		//Mockito.doReturn("Customer updated successfully").when(service).updateCustomer(customer);
		//doThrow(new CustomerNotFound()).when(service).updateCustomer();
		String msg = service.updateCustomer(customer);
		assertEquals("Customer updated successfully",msg);
	}
	@Test
	public void testDeleteCustomer() throws CustomerNotFound {
		Customer customer = new Customer(1,"priya",new Date(), 45678, "priya@gmail.com", "fcgvhb");
		//Mockito.doReturn("Customer deleted successfully").when(service).deleteCustomer(customer.getCustId());
		service.addCustomer(customer);
		String msg = service.deleteCustomer(1);
		assertEquals("Customer deleted successfully",msg);
	}


	@Test
	public void testAddAccount() {
		Account account = new Account(123, 45678,"savings","xcvh", "ghjn", 567);
		//Mockito.doReturn("Account created successfully").when(service2).addAccount(account);
		String msg = service2.addAccount(account);
		assertEquals("Account created successfully",msg);
	}

	@Test
	public void testUpdateAccount() {
		Account account = new Account(123, 45678,"savings","xcvh", "ghjn", 567);
		//Mockito.doReturn("Account updated successfully").when(service2).updateAccount(account);
		String msg = service2.updateAccount(account);
		assertEquals("Account updated successfully",msg);
	}

	@Test
	public void testAddTransaction() {
		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
		//Mockito.doReturn("Transaction added").when(service3).addTransaction(transaction);
		String msg = service3.addTransaction(transaction);
		assertEquals("Transaction added",msg);
	}

}