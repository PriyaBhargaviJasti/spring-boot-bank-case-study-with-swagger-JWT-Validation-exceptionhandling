package com.fis.bankapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapp.exception.AccountNotFound;
import com.fis.bankapp.exception.NotEnoughBalance;
import com.fis.bankapp.model.Account;
import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.service.AccountService;
import com.fis.bankapp.service.TransactionService;

/*
{
"custId":1,
"accType":"savings",
"branch":"iou",
"ifsc":"poiu",
"balance":90000
}
*/
@RestController
@RequestMapping("/accounts")
public class AccountController {
	long accNoFrom;
	long accNoTo;
	double amount;
	String transType;
	@Autowired
	AccountService service;
	
	@Autowired
	TransactionService service2;

	@PostMapping("/addAccount") // http://localhost:1111/accounts/addAccount
	public String saveAccount(@RequestBody Account account) {
		return service.addAccount(account);
	}

	@PutMapping("/updateAccount") // http://localhost:1111/accounts/updateAccount
	public String updateAccount(@RequestBody Account account) {
		return service.updateAccount(account);
	}

	@DeleteMapping("/deleteAccount/{accNo}") // http://localhost:1111/accounts/deleteAccount/888
	public String deleteAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
		try {
			return service.deleteAccount(accNo);
	}
		catch (AccountNotFound anf) {
			return "Account Not Found with given Account Number";
			
		}
	}

	@GetMapping("/getAccount/{accNo}") // http://localhost:1111/accounts/getAccount/888
	public Account getAccount(@PathVariable("accNo") long accNo) throws AccountNotFound {
		
		return service.getAccount(accNo);
	
	}

	
	@GetMapping("/depositIntoBalance/{accNo}/{depositAmount}") // http://localhost:1111/accounts/depositIntoBalance/888/888
	public String depositIntoBalance(@PathVariable("accNo") long accNo,@PathVariable("depositAmount") double depositAmount) throws AccountNotFound {
		Transaction transaction = new Transaction();
		accNoTo = accNo;
		amount = amount;
		transType = "Deposit";

		try {
			
			return service.depositIntoBalance(accNo, amount);

		} catch (AccountNotFound anf) {

			return anf.getMessage();
		} finally {
			transaction.setAccNoTo(accNo);
			transaction.setAmount(amount);
			transaction.setTransType(transType);
			service2.addTransaction(transaction);
		}
	}
	
	@GetMapping("/withdrawFromBalance/{accNo}/{withdrawAmount}") // http://localhost:1111/accounts/withdrawFromBalance/888/888
	public String withdrawFromBalance(@PathVariable("accNo") long accNo,@PathVariable("withdrawAmount") double withdrawAmount) throws NotEnoughBalance, AccountNotFound {
		Transaction transaction = new Transaction();
		accNoFrom = accNo;
		amount = amount;
		transType = "Withdraw";
		try {
			
			return service.withdrawFromBalance(accNo, amount);
		} catch (AccountNotFound anf) {
			
			return anf.getMessage();
		} catch (NotEnoughBalance nef) {
			
			return nef.getMessage();
		} finally {
			transaction.setAccNoFrom(accNo);
			transaction.setAmount(amount);
			transaction.setTransType(transType);
			service2.addTransaction(transaction);
		}
		
		/*try {
			return service.withdrawFromBalance(accNo, withdrawAmount);
	}
		catch (NotEnoughBalance neb) {
			return "Not Enough Balance";
			
		}*/
	}
		
	
	@GetMapping("/FundTransfer/{AccNoFrom}/{AccNoTo}/{amount}/{transType}") // http://localhost:1111/accounts/FundTransfer/1/2/1000/NEFT
	public String FundTransfer(@PathVariable("AccNoFrom") long AccNoFrom,@PathVariable("AccNoTo") long AccNoTo,@PathVariable("amount") double amount,@PathVariable("transType") String transType) throws AccountNotFound, NotEnoughBalance{
		
		try {
			return service.FundTransfer(accNoFrom, accNoTo, amount, transType);
		} catch (AccountNotFound anf) {
			return anf.getMessage();
		} catch (NotEnoughBalance nef) {
			return nef.getMessage();
		} 
		
	}


}
